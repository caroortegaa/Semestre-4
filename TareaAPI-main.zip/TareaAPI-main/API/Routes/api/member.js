const { response } = require('express');
const express = require('express');
const router = express.Router();



const mysql = require('mysql');

// MySQL Create Connection
/*
If the following code throws the error "ER_NOT_SUPPORTED_AUTH_MODE" run this query in mysql workbench:

ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '0000';

flush privileges;

*/
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Estrella5@",
    database: "api"
});

connection.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
});

// router.use(express.urlencoded({extended: true}));

// Get a user
router.get('/user/:name', (request, response) => 
{

    connection.query(`select * from user where name='${request.params.name}';`, function(err, result) {
        if (err) throw err;
        let user = result[0];

        response.render("user", {userName: user.Name, userLastName: user.LastName, userEmail: user.email, userid: user.id});
    });

});

// Get all users
router.get('/users', (request, response) => 
{

    connection.query(`select * from user;`, function(err, result) {

        if (err) throw err;
        response.render("allUsers", { users: result });
    });
    
});

// router.post('/userValues', (request, response) => {
//     connection.query(`select * from user where name='${request.body.name}';`, function(err, result) {
//         if (err) throw err;
//         let user = result[0];
//         console.log(user);
//         response.render("update", {userName: user.Name, userLastName: user.LastName, userEmail: user.email, ogname: user.name})
//     })
// })

// Update user
router.post('/update', (request, response) => 
{
    connection.query(`Update user set name='${request.body.name}', lastname='${request.body.lastname}', email='${request.body.email}' where id='${request.body.id}'; `, function(err, result) {
        if (err) throw err;
        console.log("User updated");
    });

    response.render("update");
});

// Create a user
router.post('/', (request, response) => 
{
    if (!request.body.name || !request.body.lastname || !request.body.email)
    {
        return response.status(400).json({ msg: 'Please include a name, a last name, and an email.'})
    }

    connection.query(`Insert into User(Name, LastName, email) values('${request.body.name}', '${request.body.lastname}', '${request.body.email}');`, function(err, result) {
        if (err) throw err;
        console.log("User Created");
    });

    response.render("userCreated");
});

// Delete user
router.post('/delete', (request, response) =>{
    connection.query(`delete from user where id='${request.body.id}'`, function(err, result) {
        if (err) throw err;
        console.log("User deleted");
    });
    response.render("delete");
});

module.exports = router;
