// Node default modules (File System)
const { readFile, readFileSync } = require('fs');
const path = require("path");

// Npm module (express, mysql)
const express = require('express');
const app = express();

// Template engine
const exphbs = require('express-handlebars');
const { request } = require('http');

// Port
const PORT = 5500;

// Templating
app.engine("handlebars", exphbs({ defaultLayout : 'main' }));
app.set('view engine', 'handlebars');

app.use(express.urlencoded({extended: true}));


app.use('/api', require('./Routes/api/member'));

app.use(express.static('public'));

// Root 
app.get('/', (request, response) =>
{
    response.render("index");
    
});


app.listen(
    PORT,
    () => console.log(`It's alive on http://localhost:${PORT}`)
);