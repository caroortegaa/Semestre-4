# TareaAPI

## Preguntas

-  ¿Qué es un API?

    Una API (Application Programming Interface) es un conector entre los datos y el software con el que interactua el usuario. Los APIs son programas que reciven "pedidos", interactuan con el sistema o la base de datos y entregan de regreso la información necesaria.

-  ¿Qué es un REST API?

    Una REST (Representational State Transfer API es una API que permite que aplicaciones web se conecten con bases de datos o otras applicaciones utilizando el protocolo HTTP. Otra caracteristica de estos APIs es la manera en la que representan sus entidades de datos. Esto lo hace por medio de URIs (Uniform Resource Identifiers)

-  Menciona 3 beneficios de REST APIs

1. Todo está estandarizado por la industria de una manera muy simple.
2. Escalable y sin estado. Si la complejidad crece, puedes modificar el sistema y no te tienes que preocupar por el estado de todos los datos.
3. El rendimiento y la calidad se quedan altos aún con complejidad.

-  ¿Cómo funciona un REST API? Menciona que es y como funciona un request, un response, y CRUD.

    Rest API nos permite hacer una petición HTTP con una dirección URL para que el API la reciba y nos devuelva una respuesta. Permite la comunicación entre cliente y servidor. También organiza los datos en su URI único para que un servidor pueda diferenciar y encontrar diferentes recursos en un servidor. Un cliente hace un request a un servidor el cual de acuerdo a su base de datos va a tener una respuesta (response) específica la cual le va a devolver al cliente.
    
    Los métodos HTTP son métodos que se le pueden hacer a un servidor a través de HTTP, al hacer un request se tiene que seguir cierto formato. En este caso la parte más importante es la URI a la que se quiere acceder, pero esa URI tiene una instrucción o un "verbo" que le dice qué hacer. Los principales y más usados son:
    
    GET - lee los datos, obtienen datos de un recurso específico
    POST - crea un recurso, sube datos que serán procesados por un recurso específico
    PUT - actualiza cierto recurso, se le tiene que especificar qué es lo que se va a cambiar en una URI con un cierto ID
    DELETE - borra datos

    CRUD son las 4 funciones principales que un modelo debe de ser capaz de hacer al construir API´s para poder decir que funciona correctamente, las acciones del sistema deberían de poder entrar en una de estas 4 categorías:
                                    CRUD -> Create, Read, Update, Delete
     El equivalente de CRUD en un request de una REST API serían los métodos HTTP: 
     Create = Post
     Get = Read
     Update = Put
     Delete = Delete

-  ¿Qué es NodeJS?

NodeJS no es exactamente un lenguaje de programación, más bien es un runtime que nos permite correr Javascript en un servidor. Antes no se podía porque antes solo se podía usar Javascript en un servidor web hasta que aparecio NodeJS y cambió el web development al permitir que todo el código de un full stack esté en un lenguaje. 
En el momento que se recibe un request del cliente, node se encarga de recibir un archivo y leerlo y luego mandar un response al cliente para que pueda leer ese archivo en el servidor web.

-  ¿Qué es un callback?

    Un callback es cuando una función recibe como parámetro otra función.
    
-  ¿Qué es NPM?

    NPM son las siglas de Node Package Manager. A través de Node.js JavaScript puede ser utilizado en back-end. NPM es un gestor de paquetes, por el cual podemos obtener cualquier librería al utilizar una linea de código. 
    
-  Cómo se instala, desinstala, y actualizan paquetes con NPM?

    INSTALAR:
 
        -npm install paquete
        
    instalar y guardar en el package.json:
    
        - npm install --save
        
        ejemplo:
        
        - npm install --save lodash
        
    instalar de forma global:
    
        - npm install -g
        
    instalar última versión:
    
        - npm install @latest
        
    instalar una versión en específico:
    
        - npm install @
        
        ejemplo:
        
        - npm install lodash@4.11
     
    PARA REVISAR LOS PAQUETES INSTALADOS:
    
        - nmp list
      
    DESINSTALAR:
    
        - npm uninstall paquete
        
        - npm uninstall paquete --no-save (el paquete no va a ser removido de package.json)
      
    ACTUALIZAR DEPENDENCIAS:
    
        checar versiones de los paquetes
        
        - npm install -g npm-check-updates
        
        después de correr el comando anterior podemos utilizar: ncu en lugar de npm-check-updates
        para actualizar todos los paquetes:
        
        - ncu -u

-  ¿Dónde instala los paquetes NPM?

Los paquetes se pueden instalar de forma local (se recomienda cuando necesitas ciertas librerías para un proyecto, lo instalas en la carpeta donde se encuentren esos archivos) o global(se instala desde la línea de comando, se recomienda cuando necesitas que un paquete esté disponible desde cualquier ubicación).

-  ¿Qué es el package.json?

Es un archivo que se crea automáticamente en la carpeta raíz al crear un nuevo proyecto con npm , es un archivo de texto en formato json. Este archivo es un archivo que contiene toda la información principal del proyecto como : nombre, versión, dependencias, repositorio, autores, licencia, etc...
Esto nos da la oportunidad administrar las dependencias del proyecto y manejar el proyecto en el registro de npm (para que otros puedan descargar el proyecto y usarlo).

-  ¿Qué es un módulo?

    Un módulo en Node.js es un conjunto de objetos y funciones en JavaScript que aplicaciones externas pueden usar. Cualquier archivo es considerado un módulo si se puede usar en aplicaciones externas.
    
-  Describe el event loop de NodeJS
    Para explicar lo que es un event loop de NodeJS es necesario conocer blocking, non-blocking, operaciones síncronas y asíncronas.
    
    BLOCKING: Es esperar a que un proceso termine para continuar con el siguiente
    
    NON-BLOCKING: El programa sigue corriendo sin la obligación de esperar a que un proceso termine su ejecución. Usando operaciones asíncronas
    
    OPERACIONES SÍNCRONAS: Esperan a que el proceso termine para continuar con su ejecución
    
    OPERACIONES ASÍNCRONAS: El programa sigue corriendo sin la obligación de esperar a que un proceso termine su ejecución.
-  ¿Qué es JSON?

JSON o por sus siglas "JavaScript Object Notation", es un formato de texto muy conocido que es independiente del lenguaje JavaScript. Es el formato de intercambio de datos ideal para usar con API REST ó AJAX por su estructura ligera y compacta. Define seis tipos de valores: nulo, números, cadenas, booleanos, matrices y objetos.


