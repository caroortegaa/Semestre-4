const { response } = require('express');
const express = require('express');
const router = express.Router();



const mysql = require('mysql');

// MySQL Create Connection
/*
If the following code throws the error "ER_NOT_SUPPORTED_AUTH_MODE" run this query in mysql workbench:

ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '0000';

flush privileges;

*/
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Estrella5@",
    database: "ankakh"
});

connection.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
});

// router.use(express.urlencoded({extended: true}));

// Get a user
router.get('/ankakh/:name', (request, response) => 
{

    connection.query(`select * from juego where name='${request.params.name}';`, function(err, result) {
        if (err) throw err;
        let user = result[0];

        response.render("user", {userName: user.Name, userid: user.id});
    });

});

// Get all users
router.get('/users', (request, response) => 
{

    connection.query(`select * from user;`, function(err, result) {

        if (err) throw err;
        response.render("allUsers", { users: result });
    });
    
});

module.exports = router;