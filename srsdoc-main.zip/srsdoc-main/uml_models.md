# UML Modeling

## Table of content

- [Business Use Case Model](#business-use-case-model---movimiento-stem)
- [Subsystem Use Case Model -> Software](#subsystem-use-case-model---software)
- [Activity Diagram -> Ankakh System Use Case](#activity-diagram---ankakh-system-use-case)

## Business Use Case Model -> Movimiento STEM
![da95c2a9-0c93-4266-80e8-18ffa91c2b77](https://user-images.githubusercontent.com/57368415/110951468-b5ec3580-830a-11eb-9f65-7db49207ff67.jpg)


## Subsystem Use Case Model -> Software
![da95c2a9-0c93-4266-80e8-18ffa91c2b77](https://user-images.githubusercontent.com/57368415/110951609-e46a1080-830a-11eb-8ffc-a92b76054ed8.jpg)


## Activity Diagram -> Ankakh System Use Case
![68c9fc3f-58ba-4188-838b-b90f61ed389a](https://user-images.githubusercontent.com/57368415/110951940-4165c680-830b-11eb-9401-ff285799ca38.jpg)

